"""Read-only review of existing regression expectations; run from domain-iteration."""
from pathlib import Path
import hashlib, html, json, xml.etree.ElementTree as ET, zipfile

audit = Path('../audit-results/analytic-parabola-failures-20261024')
dest = Path('docs/analytic-parabola-20261023')
old = json.loads(Path('GPCChecker.Test.Concrete/Fixtures/model-checker-contract.json').read_text(encoding='utf-8-sig'))
actual = json.loads((audit/'isolated-temp/model-checker-contract.actual.json').read_text(encoding='utf-8-sig'))
independent = json.loads((audit/'independent-recheck.json').read_text())
curves = json.loads((audit/'curve-differences.json').read_text())
curve_points = json.loads((audit/'curve-point-differences.json').read_text())
ns = {'t':'http://microsoft.com/schemas/VisualStudio/TeamTest/2010'}
tests = []
for name in ('concrete-recheck','calculation-recheck','modelchecker-recheck'):
    for row in ET.parse(audit/(name+'.trx')).findall('.//t:UnitTestResult',ns):
        tests.append(dict(suite=name,name=row.attrib['testName'],outcome=row.attrib['outcome'],message=row.findtext('.//t:Message','',ns)))
assert len(tests)==25 and sum(t['outcome']=='Failed' for t in tests)==12
contract = {}
for group in (k for k in old if isinstance(old[k],list)):
    pairs=list(zip(old[group],actual[group]))
    assert len(old[group])==len(actual[group])
    info=dict(total=len(pairs),changed=sum(x!=y for x,y in pairs))
    if group.startswith('stress'):
        fields={}
        for field in ('concreteMinStress','steelMaxStress','ratio'):
            changes=[dict(id=x['id'],input=x['input'],before=x[field],after=y[field],delta=y[field]-x[field],percent=100*(y[field]/x[field]-1) if abs(x[field])>1e-6 else None)
                for x,y in pairs if isinstance(x.get(field),(int,float)) and isinstance(y.get(field),(int,float)) and x[field]!=y[field]]
            fields[field]=dict(count=len(changes),largestAbsolute=sorted(changes,key=lambda v:abs(v['delta']),reverse=True)[:5],
                largestRelative=sorted((v for v in changes if v['percent'] is not None),key=lambda v:abs(v['percent']),reverse=True)[:5])
        comparable=[(x,y) for x,y in pairs if isinstance(x.get('ratio'),(int,float)) and isinstance(y.get('ratio'),(int,float))]
        info.update(fields=fields,comparableVerdicts=len(comparable),changedVerdicts=[x['id'] for x,y in comparable if (x['ratio']<=1)!=(y['ratio']<=1)],
            changedRatioAvailability=sum((x.get('ratio') is None)!=(y.get('ratio') is None) for x,y in pairs),
            changedLinear=sum(bool(x.get('linearAnalysis')) and x!=y for x,y in pairs),
            changedAnalysisIds=len({x['id'].split()[1] for x,y in pairs if x!=y}))
    contract[group]=info
search = []
for name in ('r3','s1'):
    search += [r for r in map(json.loads,(audit/(name+'-search-recheck.jsonl')).read_text().splitlines()) if r['run']==1]
assert len(search)==26 and sum(not r['accepted'] for r in search)==22
border=[r for r in search if r['Id'] in ('Focus/R3/ParabolaRectangle/Plastic/ConstantN/180/30','Focus/R3/ParabolaRectangle/Plastic/ConstantN/180/330')]
report=dict(date='2026-10-24',candidateCommit='f978802e',candidateVersion='0.19.0.0',tests=tests,contract=contract,independent=independent,
    curveLimits=curves,curvePointComparisons=curve_points,searchRecheck=search,borderlineAccepted=border,
    scope='Diagnostic review only. Existing binaries from the measured candidate; current sibling Model source updates were not rebuilt into this audit. Production sources, expected values and fixtures unchanged.')
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
binary_dirs=[Path('GPCChecker.Test.Concrete/bin/Release'),Path('GPCChecker.Test.Calculation/bin/Release/net8.0'),Path('ModelChecker.Tests/bin/Release/net6.0')]
report['binaryHashes']={str(p):digest(p) for d in binary_dirs for p in d.glob('*.dll') if p.name.startswith(('GPC','MathNet','Delaunay'))}
report['benchmarkBinarySha256']=digest(Path('../audit-results/analytic-parabola-20261023/exact-complete/bin/GPCChecker.Test.Concrete.dll'))
report['fixtureHashes']={str(p):digest(p) for p in Path('GPCChecker.Test.Concrete/Fixtures').glob('*') if p.is_file() and p.name in ('model-checker-contract.json','stress-legacy.csv','stress-sections.xml','curvature-contract-0.0.17.csv','curvature-legacy.csv','domain-point-contract.json')}
json_path=dest/'controllo-fallimenti-20261024.json'
json_path.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

def f(v,n=3): return f'{v:.{n}f}'.replace('.',',')
def table(head,rows):
    return '<div class="scroll"><table><thead><tr>'+''.join('<th>'+html.escape(str(x))+'</th>' for x in head)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+html.escape(str(x))+'</td>' for x in row)+'</tr>' for row in rows)+'</tbody></table></div>'
parts=['''<!doctype html><html lang="it"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Ricontrollo dei casi falliti — 24 ottobre 2026</title>
<style>body{font:16px/1.55 system-ui,sans-serif;background:#f3f6f4;color:#18362c;margin:0}main{max-width:1200px;margin:auto;padding:30px}h1{line-height:1.2}h2{margin-top:30px}table{border-collapse:collapse;background:white;width:100%;font-size:14px}td,th{padding:10px;border-bottom:1px solid #d9e2dc;text-align:left;vertical-align:top}th{background:#e0ece5}.scroll{overflow:auto}.box{padding:15px 20px;background:white;border-left:5px solid #24856b}a{color:#086749}pre{white-space:pre-wrap;font-size:12px}</style><main>
<p>Checker Concrete 0.19.0.0 · commit f978802e · 24 ottobre 2026</p><h1>Quali casi non tornano, e quanto contano?</h1>
<div class="box">Le verifiche indipendenti eseguite confermano la nuova integrazione nei casi approfonditi. I sette nuovi fallimenti derivano dal confronto con la spezzata precedente. Non tutte le variazioni sono però trascurabili: le curvature a basso carico cambiano di alcuni punti percentuali, e due casi di resistenza al bordo vengono accettati grazie alla tolleranza su N. Il contratto materiale tra Model e Checker deve essere allineato prima del rilascio.</div>
<p>Rieseguiti 25 test mirati: 13 superati e gli stessi 12 falliti della verifica completa; tra i superati, tutti i nove nuovi test analitici. I due contratti che scrivono file temporanei sono stati ripetuti in una cartella isolata. Nessun atteso, fixture, tolleranza o sorgente di produzione è stato modificato. La suite completa precedente resta 5605 superati e 12 falliti: non è stata rieseguita integralmente oggi.</p><h2>I dodici fallimenti</h2>''']
parts.append(table(['Gruppo','Numero','Causa verificata','Significatività'],[
['LegacyStressStatesAreReproduced (Concrete e Calculation), ModelCheckerContractOf0017IsUnchanged','3 nuovi','Stesso cambio di legge negli stati SLE; confrontato l’intero snapshot, non soltanto il primo valore.','Piccole variazioni di tensione; contratto da rivalidare.'],
['NonLinearAnalysisIsInEquilibrium: (−800,150,0) e (−1500,60,−30), kN/kNm','2 nuovi','Il test reintegra il piano analitico con la spezzata di Model.','Controlli essenziali; il riesame con la stessa legge e integrazione indipendente conferma l’equilibrio.'],
['NonLinearAxialCompressionFollowsTheParabola','1 nuovo','Il riferimento del test risolve in realtà la legge tabulata.','Deformazione diversa dello 0,627%; la nuova soluzione coincide quasi con la radice analitica.'],
['StressAnalysisFollowsTheIndependentFibreModel','1 nuovo','Gli attesi usano esplicitamente otto corde in compressione.','Variazione di curvatura fino al 2,51%; non è semplice arrotondamento.'],
['DomainPointContractOf0017IsUnchanged, CurvatureContractOf0017IsUnchanged, LegacyMomentCurvatureIsReproduced','3 preesistenti','Fotografie storiche già differenti prima di questa candidata; approfondite le cinque curve native.','Le differenze vanno quantificate; non basta il primo messaggio del test.'],
['LargeSectionPointBeyondTheStoppingTestIsAccepted, RealDetailsMatchNativeResistanceAndKeepThePreparedForceFrame','2 preesistenti','Si fermano su precondizioni che pretendevano un residuo elevato o un punto grezzo non accettato.','Il risultato è migliorato. Va riprogettato il caso di prova mantenendo i successivi controlli funzionali.']]))
parts += ['<h2>Equilibrio sui casi esatti che falliscono</h2><p>Rettangolo 300×500 mm, C25/30, sei barre Ø18, StandardEN1992p11. Stesso piano restituito, reintegrazione indipendente su 600.000 fibre, prima con la spezzata e poi con la formula quadratica. Compressione negativa.</p>']
rows=[]
for c in independent['equilibrium'][:2]:
    oldr=next(r for r in c['results'] if not r['analytic'] and r['fibres']==600000)
    newr=next(r for r in c['results'] if r['analytic'] and r['fibres']==600000)
    rows.append([f"{c['N_kN']}; {c['Mx_kNm']}; {c['My_kNm']}",f(abs(oldr['residualN'])/1000),f(abs(newr['residualN']),4),f(max(abs(newr['residualMx']),abs(newr['residualMy']))/1e6,7)])
parts.append(table(['N; Mx; My [kN; kNm; kNm]','|ΔN| con spezzata [kN]','|ΔN| con parabola [N]','Massimo |ΔM| con parabola [kNm]'],rows))
u=independent['uniform']
parts += [f'<p>Compressione uniforme, N = −1800 kN, quattro Ø18: ε precedente = {u["oldStrain"]:.12g}; ε candidata = {u["actualStrain"]:.12g}; radice analitica indipendente = {u["exactStrain"]:.12g}. Scarto della candidata dalla radice: {f(abs(100*(u["actualStrain"]/u["exactStrain"]-1)),6)}%. La radice risolve N = −fcd·(2r−r²)·(Ac−As) − Es·εc2·r·As, con r = |ε|/εc2 e acciaio elastico nel caso verificato.</p>',
'<h2>Stati SLE: controllo completo della fixture</h2><p>639 righe su 2016 cambiano, corrispondenti a 216 identificativi di analisi con combinazioni correlate. Nessuna variazione nei casi lineari. Sui 1344 confronti con indice di verifica numerico non cambia l’esito rispetto al limite 1; non cambia neppure la disponibilità dell’indice negli altri casi. Questo vale per il catalogo verificato, non garantisce l’invarianza per ogni modello vicino a un limite.</p>']
parts.append(table(['Quantità','Massima variazione assoluta','Nota'],[
['Tensione del calcestruzzo','0,03130 MPa','La massima variazione relativa è 4,46%, ma su una tensione iniziale di soli 0,161 MPa.'],
['Tensione dell’acciaio','0,95963 MPa','La massima variazione relativa è −4,86%, da 9,181 a 8,735 MPa.'],
['Indice di verifica','0,002038','Nessun attraversamento del limite nei confronti applicabili.'],
['Contratti di fessurazione','0 differenze','2979 record complessivi tra fixture, casi limite, griglia e profili.']]))
parts += ['<h2>Tension stiffening: verifica indipendente dei tre casi</h2><p>Sezione 300×500 mm, C25/30, quattro Ø16. Calcolo indipendente con primitive della parabola in compressione e dei due rami della legge di trazione; risoluzione delle due equazioni N e M per deformazione e curvatura. Il percorso misto della candidata usa ancora Gauss.</p>']
parts.append(table(['N [kN]','M [kNm]','χ precedente [1/mm]','χ candidata [1/mm]','Variazione [%]','Scarto da soluzione indipendente [%]'],[
[c['N_kN'],c['M_kNm'],f"{c['oldCurvature']:.9g}",f"{c['actualCurvature']:.9g}",f(100*(c['actualCurvature']/c['oldCurvature']-1),4),f(100*(c['actualCurvature']/c['independentCurvature']-1),6)] for c in independent['tensionStiffening']]))
parts += ['<p>Lo scarto massimo dalla soluzione indipendente è circa 0,051%. Il residuo massimo di momento sul piano restituito è 0,00564 kNm. Il calo di curvatura del 2,51% del primo caso è principalmente conseguenza della nuova legge, non un errore d’integrazione di quella grandezza.</p>',
'<h2>Curve momento-curvatura: cosa cambia oltre il primo assert</h2>']
parts.append(table(['Caso','M limite prima [kNm]','M limite dopo [kNm]','ΔM [%]','Δχ snervamento [%]','Δχ ultima [%]'],[
[c['case'],f(c['momentBefore_kNm']),f(c['momentAfter_kNm']),f(c['momentChangePercent'],4),f(c['yieldChangePercent'],4),f(c['ultimateChangePercent'],4)] for c in curves]))
parts += ['<p>Le cinque curve conservano 42 punti. Nei tratti iniziali, confrontando punti corrispondenti delle curve, la variazione di curvatura raggiunge −5,17% per R400x400. Il momento associato passa da 3,36618 a 3,37006 kNm: sono punti alla stessa frazione del rispettivo momento limite, non esattamente allo stesso momento. La pendenza iniziale della parabola è superiore del 6,67% a quella della prima corda della vecchia tabella. Queste variazioni SLE sono da documentare, anche quando i momenti ultimi cambiano poco.</p>',
'<h2>Le ricerche non riuscite del benchmark</h2><p>Rieseguite 26 ricerche: 24 su R3 e due su S1. Confermati 20 rifiuti su R3, due su S1 e quattro accettazioni su R3. Nessuno è un nuovo fallimento introdotto dalla parabola analitica. La sezione del dominio a N assegnato è stata ricostruita separatamente: scansione dell’orientamento del piano e bisezione in ciascun campo di deformazione, con 360 e 1440 direzioni. I massimi riportati sono stime numeriche convergenti, non una dimostrazione globale di ammissibilità.</p>']
parts.append(table(['Caso','Richiesta','Riscontro'],[
['R3 300×500, 3Ø20 solo inferiori, N=+180 kN','9 direzioni Plastic e 11 Elastic non riuscite','Intervallo angolare della risultante circa ±29,886° Plastic e ±18,592° Elastic. Le direzioni rifiutate sono esterne.'],
['S1 1000×200, 10Ø12, Elastic, N=+221,277 kN','ConstantNMx, Mx=±20 kNm','Nella sezione del dominio a questo N, massimo |Mx| ≈13,0815 kNm: il vincolo Mx=±20 non è raggiungibile.']]))
parts += ['<div class="box"><b>Casi accettati di bordo da non confondere con soluzioni a N esatto.</b> R3 Plastic a ±30° passa con N ≈179,5115 kN anziché 180 kN, cioè un residuo di circa 488,49 N entro la tolleranza di 1000 N. La scansione a N esatto arriva a ±29,8856°. Anche prima questi casi passavano grazie alla tolleranza. Il massimo scarto di momento di circa −1,90% del report precedente cade proprio in questo gruppo: non va letto come puro errore o puro effetto fisico della parabola.</div>',
'<h2>Valutazione e attività prima del rilascio</h2><ul><li>Conservare la parabola analitica: i controlli indipendenti approfonditi la confermano.</li><li>Allineare la legge esposta da Model e quella usata da Checker: oggi reintegrare un piano con una API diversa può produrre uno squilibrio apparente.</li><li>Rivalidare gli attesi SLE e le curve sulla legge deliberatamente scelta; alcuni scarti sono percentuali e non vanno nascosti ampliando le tolleranze.</li><li>Riprogettare le due precondizioni di test divenute obsolete. Il fallimento iniziale impedisce ai test originali di raggiungere tutte le asserzioni successive: quelle non sono dichiarate superate da questo audit.</li><li>Tenere separati i casi fuori dominio e quelli ammessi solo entro tolleranza. Migliorare la diagnosi della richiesta incompatibile evita fallback costosi e risultati grezzi che un chiamante potrebbe usare senza controllarne la convergenza.</li></ul>',
'<h2>Riproducibilità</h2><p>Usati i binari conservati della candidata misurata, con hash nel JSON. Gli aggiornamenti successivi dei sorgenti del checkout fratello Model non sono stati ricompilati in questo audit. La diagnostica indipendente gira su .NET 8; i test Concrete sono stati ripetuti su .NET Framework 4.7.2, Calculation su .NET 8 e ModelChecker su .NET 6. I file temporanei condivisi non sono usati come prova: fanno fede le copie prodotte nella cartella isolata.</p>',
'<p><a href="controllo-fallimenti-20261024.json">Risultati e impronte</a> · <a href="controllo-fallimenti-20261024.zip">Codice diagnostico, TRX e dati</a> · <a href="report-prima-dopo.html">Report prestazioni</a></p></main></html>']
(dest/'controllo-fallimenti-20261024.html').write_text('\n'.join(parts),encoding='utf-8')
included=[audit/'Review.py',audit/'diagnostic/Program.cs',audit/'diagnostic/Diagnostic.csproj',audit/'independent-recheck.json',audit/'curve-differences.json',audit/'curve-point-differences.json']
included += list(audit.glob('*.trx')) + list(audit.glob('*recheck.jsonl'))
included += [audit/'isolated-temp/model-checker-contract.actual.json',audit/'isolated-temp/curvature-contract-0.0.17.csv.actual']
with zipfile.ZipFile(dest/'controllo-fallimenti-20261024.zip','w',zipfile.ZIP_DEFLATED) as z:
    for p in included: z.write(p,p.relative_to(audit).as_posix())
report['evidenceArchiveSha256']=digest(dest/'controllo-fallimenti-20261024.zip')
report['auditSourceSha256']={p.relative_to(audit).as_posix():digest(p) for p in included if p.suffix in ('.py','.cs','.csproj')}
json_path.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('Reviewed:',len(tests),'tests;',len(search),'search cases; 639/2016 SLE rows differ; expected fixtures unchanged.')
