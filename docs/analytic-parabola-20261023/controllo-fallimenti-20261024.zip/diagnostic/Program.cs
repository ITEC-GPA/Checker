using System;
using System.Linq;
using System.Collections.Generic;
using System.Reflection;
using System.Text.Json;
using GPC.Checkers.Concrete.Checkers;
using GPC.Checkers.Concrete.Results;
using GPC.Checkers.Concrete.Helper;
using GPC.Checkers.Concrete.SectionSolvers;
using GPC.Geometry;
using GPC.Model.Materials;
using GPC.Model.Results;
using GPC.Model.Sections.Concrete;
using GPC.Model.Standards;

class Program
{
    const BindingFlags Flags = BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static;
    static object Call(Type type, object instance, string name, params object[] args) => type.GetMethods(Flags).Single(m => m.Name == name && m.GetParameters().Length == args.Length).Invoke(instance, args);
    static double Stress(double e, double fc) => e >= 0 || e < -.0035 ? 0 : e <= -.002 ? -fc : -fc * (2 * (e / -.002) - Math.Pow(e / -.002, 2));
    static object MainResult()
    {
        var t = typeof(ConcreteTests.ConcreteControlTests);
        object instance = Activator.CreateInstance(t);
        var corners = new[] { (50.0,50.0,18.0),(250.0,50.0,18.0),(250.0,450.0,18.0),(50.0,450.0,18.0) };
        var standard = new StandardEN1992p11();
        ReinforcedConcreteSection Section(bool six) => (ReinforcedConcreteSection)Call(t,instance,"Rect",300.0,500.0,six ? corners.Concat(new[] {(150.0,50.0,18.0),(150.0,450.0,18.0)}) : corners,null,null);
        SectionCheckerModelCode2010 Checker(ReinforcedConcreteSection s) => (SectionCheckerModelCode2010)Call(t,instance,"Checker",s,standard,false,SectionSolver.StressAnalysisTypes.NonLinear,SectionSolver.FailureAnalysisTypes.ConstantEccentricity);
        ResultBeamForces Force(ReinforcedConcreteSection s, double n, double mx, double my) => (ResultBeamForces)Call(t,instance,"Force",s,n,mx,my);
        var equilibrium = new List<object>();
        foreach(var load in new[] {(-800.0,150.0,0.0),(-1500.0,60.0,-30.0),(0.0,100.0,0.0),(-300.0,-90.0,25.0)})
        {
            var s = Section(true); var checker = Checker(s);
            var p = checker.SectionSolver.GetStressAnalysisResult(Force(s,load.Item1,load.Item2,load.Item3)).StrainPlane;
            double fc = -s.ConcreteMaterial.CalculateDesignStressFromCharacteristic(standard,-25);
            var results = new List<object>();
            foreach(bool analytic in new[] {false,true})
            foreach(int resolution in new[] {1,4})
            {
                int nx=150*resolution,ny=250*resolution;
                double dx=300.0/nx,dy=500.0/ny,n=0,mx=0,my=0;
                double Concrete(double e) => analytic ? Stress(e,fc) : e<0 ? s.ConcreteMaterial.CalculateDesignStressConcrete(standard,e) : 0;
                for(int i=0;i<nx;i++) for(int j=0;j<ny;j++)
                {
                    double x=(i+.5)*dx,y=(j+.5)*dy,f=Concrete(p.GetStrain(x,y))*dx*dy;
                    n+=f; mx-=f*(y-250); my+=f*(x-150);
                }
                foreach(var bar in s.GetRebars())
                {
                    double e=p.GetStrain(bar.Position),f=(bar.RebarMaterial.CalculateDesignStress(standard,e)-Concrete(e))*bar.Area;
                    n+=f;mx-=f*(bar.Position.Y-250);my+=f*(bar.Position.X-150);
                }
                results.Add(new{analytic,fibres=nx*ny,n,mx,my,residualN=n-load.Item1*1000,residualMx=mx-load.Item2*1e6,residualMy=my-load.Item3*1e6});
            }
            equilibrium.Add(new{N_kN=load.Item1,Mx_kNm=load.Item2,My_kNm=load.Item3,results});
        }
        var axial=Section(false);var axialPlane=Checker(axial).SectionSolver.GetStressAnalysisResult(Force(axial,-1800,0,0)).StrainPlane;
        double areaSteel=axial.GetRebars().Sum(b=>b.Area),fcAxial=25/1.5,qa=fcAxial*(150000-areaSteel),qb=2*qa+200000*.002*areaSteel;
        double exact=-.002*3600000/(qb+Math.Sqrt(qb*qb-4*qa*1800000));
        var uniform=new{N_kN=-1800,exactStrain=exact,actualStrain=axialPlane.GetStrain(0,0),oldStrain=-.000833871997981407};
        var testAssembly=t.Assembly;
        var tsType=typeof(ConcreteTests.StressAnalysisTensionStiffeningTests);
        var symmetric=(ReinforcedConcreteSection)Call(testAssembly.GetType("ConcreteTests.UltimateSections"),null,"Symmetric");
        var local=(CoordinateSystem)Call(typeof(ConcreteTests.DomainPointContractTests),null,"LocalAxes",symmetric);
        var ts = new List<object>();
        foreach(var c in new[] {(0.0,20.0,2.963356e-7),(0.0,45.0,9.555532e-7),(-300.0,60.0,1.198912e-6)})
        {
            var checker=(SectionCheckerModelCode2010)Call(tsType,null,"Checker",symmetric,false,ConcreteMaterial.TensionResponseDiagrams.TensionStiffening,SectionSolver.FailureAnalysisTypes.ConstantN);
            var force=(ResultBeamForces)Call(typeof(ConcreteTests.DomainPointContractTests),null,"Force",local,c.Item1,c.Item2,0.0);
            var result=checker.GetTensionAnalysisResult(force);var plane=result.StrainPlane;
            var law=symmetric.ConcreteMaterial.GetTensionStiffening();
            double fc=.85*25/1.5,ec=law.ElasticModulus,fct=law.TensileStrength;
            var vertices=symmetric.ConcreteShape.GetPoints2d();
            var comp=vertices.OrderBy(v=>plane.GetStrain(v)).First();
            var tens=vertices.OrderBy(v=>plane.GetStrain(v)).Last();
            double e0=plane.GetStrain(0,0),chi=plane.ChiY;
            double Sig(double e) => e<=0 ? Stress(e,fc) : e<=fct/ec ? ec*e : fct/(1+Math.Sqrt(500*e));
            double F(double e)
            {
                if(e<-.002) return F(-.002)-fc*(Math.Max(e,-.0035)+.002);
                if(e<=0) return fc*(500*e*e+250000*e*e*e/3);
                if(e<=fct/ec) return ec*e*e/2;
                double u=Math.Sqrt(500*e),v=Math.Sqrt(500*fct/ec);
                return F(fct/ec)+2*fct/500*(u-Math.Log(1+u)-v+Math.Log(1+v));
            }
            double G(double e)
            {
                if(e<-.002) { double z=Math.Max(e,-.0035);return G(-.002)-fc*(z*z-.002*.002)/2; }
                if(e<=0) return fc*(1000*e*e*e/3+250000*Math.Pow(e,4)/4);
                if(e<=fct/ec) return ec*e*e*e/3;
                double H(double u)=>u*u*u/3-u*u/2+u-Math.Log(1+u);
                return G(fct/ec)+2*fct/(500*500)*(H(Math.Sqrt(500*e))-H(Math.Sqrt(500*fct/ec)));
            }
            (double n,double mx) Integrate(double origin,double gradient)
            {
                double bottom=origin-250*gradient,top=origin+250*gradient;
                double df=F(top)-F(bottom),dg=G(top)-G(bottom);
                double n=300*df/gradient,mx=-300*(dg-origin*df)/(gradient*gradient);
                foreach(var bar in symmetric.GetRebars())
                {
                    double e=origin+gradient*bar.Position.Y;
                    double stress=Math.Max(-450/1.15,Math.Min(450/1.15,200000*e));
                    double f=(stress-Sig(e))*bar.Area;n+=f;mx-=f*bar.Position.Y;
                }
                return(n,mx);
            }
            var integrated=Integrate(e0,chi);
            double refE=e0,refChi=chi;
            for(int it=0;it<15;it++)
            {
                var v=Integrate(refE,refChi);var de=Integrate(refE+1e-9,refChi);var dk=Integrate(refE,refChi+1e-11);
                double a=(de.n-v.n)/1e-9,b=(dk.n-v.n)/1e-11,cc=(de.mx-v.mx)/1e-9,d=(dk.mx-v.mx)/1e-11;
                double rn=c.Item1*1000-v.n,rm=c.Item2*1e6-v.mx,det=a*d-b*cc;
                refE+=(d*rn-b*rm)/det;refChi+=(-cc*rn+a*rm)/det;
            }
            var independent=Integrate(refE,refChi);
            ts.Add(new{N_kN=c.Item1,M_kNm=c.Item2,oldCurvature=c.Item3,actualCurvature=Math.Sqrt(plane.ChiX*plane.ChiX+chi*chi),chiX=plane.ChiX,
                independentCurvature=Math.Abs(refChi),independentResidualN=independent.n-c.Item1*1000,independentResidualM=independent.mx-c.Item2*1e6,
                planeResidualN=integrated.n-c.Item1*1000,planeResidualM=integrated.mx-c.Item2*1e6,
                concreteStress=result.GetConcreteTension(comp),analyticConcreteStress=Sig(plane.GetStrain(comp)),tensileStress=result.GetConcreteTension(tens),ec,fct});
        }
        return new{equilibrium,uniform,tensionStiffening=ts,domainSlices=DomainSlices()};
    }
    static object DomainSlices()
    {
        var bench=typeof(ConcreteTests.DomainPointContractTests);
        var sections=(Array)bench.GetField("Sections",Flags).GetValue(null);
        object r3=sections.Cast<object>().Single(s=>(string)s.GetType().GetField("Name").GetValue(s)=="R3");
        object s1=Activator.CreateInstance(r3.GetType());
        void Set(string name,object value)=>s1.GetType().GetField(name).SetValue(s1,value);
        Set("Name","S1");Set("Width",1000.0);Set("Height",200.0);Set("Fck",25.0);
        Set("Bars",Enumerable.Range(0,5).SelectMany(i=>new[]{new[]{-400+200.0*i,-60.0,12.0},new[]{-400+200.0*i,60.0,12.0}}).ToArray());
        var build=typeof(SectionSolver).GetMethod("BuildPlane",Flags);
        var integrate=typeof(SectionSolver).GetMethods(Flags).Single(m=>m.Name=="CalculateForceResultantForDomain" && m.GetParameters().Length==1);
        var output=new List<object>();
        foreach(var scenario in new[]{(r3,SectionSolver.FailureDomainTypes.Plastic,180000.0),(r3,SectionSolver.FailureDomainTypes.Elastic,180000.0),(s1,SectionSolver.FailureDomainTypes.Elastic,221277.0)})
        {
            var section=(ReinforcedConcreteSection)Call(bench,null,"BuildSection",scenario.Item1,ConcreteMaterial.CompressionStressStrainDiagrams.ParabolaRectangle);
            var solver=((SectionCheckerModelCode2010)Call(bench,null,"BuildChecker",section,scenario.Item2)).SectionSolver;
            var fields=((ValueTuple<SectionSolver.FailureZones,int>[])Call(typeof(SectionSolver),solver,"GetFailureZonesDiscretization",scenario.Item2)).Select(v=>v.Item1).ToArray();
            foreach(int divisions in new[]{360,1440})
            {
                var points=new List<ForceTuple>();
                for(int j=0;j<divisions;j++)
                foreach(var field in fields)
                {
                    double theta=2*Math.PI*j/divisions;
                    ForceTuple At(double eta)=>(ForceTuple)integrate.Invoke(solver,new[]{build.Invoke(solver,new object[]{theta,scenario.Item2,field,eta,-1})});
                    double lo=0,hi=1,na=At(lo).N-scenario.Item3,nb=At(hi).N-scenario.Item3;
                    if(!double.IsFinite(na) || !double.IsFinite(nb) || na*nb>0)continue;
                    for(int i=0;i<48;i++) {double mid=(lo+hi)/2,nm=At(mid).N-scenario.Item3;if(nm*na>0){lo=mid;na=nm;}else hi=mid;}
                    points.Add(At((lo+hi)/2));
                }
                output.Add(new{section=(string)scenario.Item1.GetType().GetField("Name").GetValue(scenario.Item1),state=scenario.Item2.ToString(),N=scenario.Item3,divisions,points=points.Count,
                    maxAxialResidual=points.Max(p=>Math.Abs(p.N-scenario.Item3)),minMx=points.Min(p=>p.Mx),maxMx=points.Max(p=>p.Mx),minMy=points.Min(p=>p.My),maxMy=points.Max(p=>p.My),
                    minAngleDeg=points.Min(p=>Math.Atan2(p.My,p.Mx)*180/Math.PI),maxAngleDeg=points.Max(p=>Math.Atan2(p.My,p.Mx)*180/Math.PI)});
            }
        }
        return output;
    }
    static void Main(string[] args) => System.IO.File.WriteAllText(args[0],JsonSerializer.Serialize(MainResult(),new JsonSerializerOptions{WriteIndented=true}));
}
